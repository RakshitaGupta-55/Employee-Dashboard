import { useEffect, useState } from "react";
import EmployeeForm from "./EmployeeForm";
import EmployeeTable from "./EmployeeTable";
import type { Employee } from "../utils/storage";
import { getEmployees, saveEmployees } from "../utils/storage";

interface Props {
  onLogout: () => void;
}

const Dashboard = ({ onLogout }: Props) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [editing, setEditing] = useState<Employee | null>(null);

  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    inactive: 0,
    male: 0,
    female: 0,
    transgender: 0,
  });

  const updateStats = (emps: Employee[]) => {
    setStats({
      total: emps.length,
      active: emps.filter((e) => e.active).length,
      inactive: emps.filter((e) => !e.active).length,
      male: emps.filter((e) => e.gender === "Male").length,
      female: emps.filter((e) => e.gender === "Female").length,
      transgender: emps.filter((e) => e.gender === "Transgender").length,
    });
  };

  useEffect(() => {
    const loadedEmployees = getEmployees();
    setEmployees(loadedEmployees);
    updateStats(loadedEmployees);
  }, []);

  const saveEmployee = (emp: Employee) => {
    let updatedEmployees: Employee[];

    if (editing) {
      updatedEmployees = employees.map((e) => (e.id === emp.id ? emp : e));
    } else {
      updatedEmployees = [...employees, { ...emp, id: Date.now() }];
    }

    setEmployees(updatedEmployees);
    saveEmployees(updatedEmployees);
    updateStats(updatedEmployees);
    setEditing(null);
  };

  const deleteEmployee = (id: number) => {
    if (!window.confirm("Are you sure you want to delete this employee?"))
      return;

    const updatedEmployees = employees.filter((e) => e.id !== id);
    setEmployees(updatedEmployees);
    saveEmployees(updatedEmployees);
    updateStats(updatedEmployees);
  };

  return (
    <>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-30px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }

        .dashboard-wrapper {
          min-height: 100vh;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 20px;
        }

        .dashboard-container {
          max-width: 1400px;
          margin: 0 auto;
        }

        .dashboard-header {
          background: white;
          border-radius: 20px;
          padding: 25px 35px;
          margin-bottom: 25px;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
          animation: slideDown 0.6s ease;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 15px;
        }

        .dashboard-title {
          margin: 0;
          font-weight: 700;
          font-size: 32px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .btn-logout {
          background: linear-gradient(135deg, #33eb92ff 0%, #7543f4ff 100%);
          color: white;
          border: none;
          border-radius: 12px;
          padding: 14px 30px;
          font-weight: 600;
          font-size: 15px;
          cursor: pointer;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .btn-logout:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 25px rgba(235, 51, 73, 0.4);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-bottom: 25px;
          animation: fadeIn 0.8s ease;
        }

        .stat-card {
          background: white;
          border-radius: 16px;
          padding: 25px;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
          transition: all 0.3s ease;
          position: relative;
          overflow: hidden;
          animation: scaleIn 0.6s ease;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.15s; }
        .stat-card:nth-child(3) { animation-delay: 0.2s; }
        .stat-card:nth-child(4) { animation-delay: 0.25s; }
        .stat-card:nth-child(5) { animation-delay: 0.3s; }
        .stat-card:nth-child(6) { animation-delay: 0.35s; }

        .stat-card:hover {
          transform: translateY(-5px) scale(1.02);
          box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .stat-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 5px;
          background: var(--stat-gradient);
        }

        .stat-card.total { --stat-gradient: linear-gradient(90deg, #667eea, #764ba2); }
        .stat-card.active { --stat-gradient: linear-gradient(90deg, #11998e, #38ef7d); }
        .stat-card.inactive { --stat-gradient: linear-gradient(90deg, #eb3349, #f45c43); }
        .stat-card.male { --stat-gradient: linear-gradient(90deg, #4facfe, #00f2fe); }
        .stat-card.female { --stat-gradient: linear-gradient(90deg, #fa709a, #fee140); }
        .stat-card.transgender { --stat-gradient: linear-gradient(90deg, #f093fb, #f5576c); }

        .stat-icon {
          font-size: 32px;
          margin-bottom: 10px;
          display: block;
        }

        .stat-label {
          font-size: 14px;
          font-weight: 600;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
        }

        .stat-value {
          font-size: 36px;
          font-weight: 700;
          background: var(--stat-gradient);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          line-height: 1;
        }

        .content-row {
          display: grid;
          grid-template-columns: 1fr 2fr;
          gap: 25px;
          animation: slideUp 0.8s ease;
        }

        @media (max-width: 1024px) {
          .content-row {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 768px) {
          .dashboard-wrapper {
            padding: 15px;
          }

          .dashboard-header {
            padding: 20px;
            flex-direction: column;
            text-align: center;
          }

          .dashboard-title {
            font-size: 26px;
            justify-content: center;
          }

          .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
          }

          .stat-card {
            padding: 20px;
          }

          .stat-value {
            font-size: 30px;
          }

          .btn-logout {
            width: 100%;
            justify-content: center;
          }
        }

        @media (max-width: 480px) {
          .stats-grid {
            grid-template-columns: 1fr;
          }

          .dashboard-title {
            font-size: 22px;
          }

          .stat-icon {
            font-size: 28px;
          }

          .stat-value {
            font-size: 28px;
          }
        }
      `}</style>

      <div className="dashboard-wrapper">
        <div className="dashboard-container">
          {/* Header */}
          <div className="dashboard-header">
            <h3 className="dashboard-title">
              <span>📊</span>
              Employee Dashboard
            </h3>
            <button className="btn-logout" onClick={onLogout}>
              <span>🚪</span>
              Logout
            </button>
          </div>

          {/* Statistics Cards */}
          <div className="stats-grid">
            <div className="stat-card total">
              <span className="stat-icon">👥</span>
              <div className="stat-label">Total Employees</div>
              <div className="stat-value">{stats.total}</div>
            </div>

            <div className="stat-card active">
              <span className="stat-icon">✓</span>
              <div className="stat-label">Active</div>
              <div className="stat-value">{stats.active}</div>
            </div>

            <div className="stat-card inactive">
              <span className="stat-icon">✗</span>
              <div className="stat-label">Inactive</div>
              <div className="stat-value">{stats.inactive}</div>
            </div>

            <div className="stat-card male">
              <span className="stat-icon">♂️</span>
              <div className="stat-label">Male</div>
              <div className="stat-value">{stats.male}</div>
            </div>

            <div className="stat-card female">
              <span className="stat-icon">♀️</span>
              <div className="stat-label">Female</div>
              <div className="stat-value">{stats.female}</div>
            </div>

            <div className="stat-card transgender">
              <span className="stat-icon">⚧️</span>
              <div className="stat-label">Transgender</div>
              <div className="stat-value">{stats.transgender}</div>
            </div>
          </div>

          {/* Main Content */}
          <div className="content-row">
            <div>
              <EmployeeForm onSave={saveEmployee} editing={editing} />
            </div>
            <div>
              <EmployeeTable
                data={employees}
                onEdit={setEditing}
                onDelete={deleteEmployee}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;