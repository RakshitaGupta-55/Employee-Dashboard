import { useState } from "react";
import type { Employee } from "../utils/storage";

interface Props {
  data: Employee[];
  onEdit: (e: Employee) => void;
  onDelete: (id: number) => void;
}

const EmployeeTable = ({ data, onEdit, onDelete }: Props) => {
  const [search, setSearch] = useState("");
  const [gender, setGender] = useState("");
  const [status, setStatus] = useState("");

  const filtered = data.filter(
    (e) =>
      e.name.toLowerCase().includes(search.toLowerCase()) &&
      (gender ? e.gender === gender : true) &&
      (status ? String(e.active) === status : true)
  );

  return (
    <>
      <style>{`
        /* ================= PRINT FIX ================= */
        @media print {
          /* Force employee data to start from second page */
          .employees-table tbody tr:first-child {
            page-break-before: always;
            break-before: page;
          }

          /* Prevent row splitting */
          tr, td, th {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* Hide action buttons & print button */
          .action-buttons,
          .print-button {
            display: none !important;
          }

          /* Remove shadows & hover effects */
          .employee-table-card {
            box-shadow: none !important;
            padding: 0 !important;
          }

          .employees-table tbody tr:hover {
            transform: none !important;
            box-shadow: none !important;
          }
        }

        /* ================= EXISTING UI ================= */
        .employee-table-card {
          border-radius: 16px;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
          background: white;
          padding: 30px;
        }

        .filters-wrapper {
          display: grid;
          grid-template-columns: 2fr 1fr 1fr auto;
          gap: 12px;
          margin-bottom: 25px;
        }

        .filter-field-input,
        .filter-field-select {
          border: 2px solid #e8e8e8;
          border-radius: 10px;
          padding: 12px 16px;
          font-size: 15px;
          width: 100%;
        }

        .print-button {
          background: linear-gradient(135deg, #667eea, #764ba2);
          color: white;
          border: none;
          border-radius: 10px;
          padding: 12px 24px;
          font-weight: 600;
          cursor: pointer;
        }

        .table-wrapper {
          overflow-x: auto;
          border-radius: 12px;
        }

        .employees-table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
        }

        .employees-table thead {
          background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .employees-table th {
          color: white;
          padding: 16px;
          text-align: left;
        }

        .employees-table td {
          padding: 16px;
          vertical-align: middle;
        }

        .profile-image {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          object-fit: cover;
        }

        .profile-initials {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: linear-gradient(135deg, #667eea, #764ba2);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 20px;
        }

        .employee-name {
          font-weight: 600;
        }

        .gender-display {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .status-pill {
          padding: 8px 16px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 700;
        }

        .status-pill-active {
          background: #38ef7d;
          color: white;
        }

        .status-pill-inactive {
          background: #f45c43;
          color: white;
        }

        .action-buttons {
          display: flex;
          gap: 8px;
        }

        .action-btn {
          padding: 8px 14px;
          border-radius: 8px;
          border: none;
          color: white;
          font-weight: 600;
          cursor: pointer;
        }

        .action-btn-edit {
          background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .action-btn-delete {
          background: linear-gradient(135deg, #eb3349, #f45c43);
        }
      `}</style>

      <div className="employee-table-card">
        <div className="filters-wrapper">
          <input
            className="filter-field-input"
            placeholder="🔍 Search employees by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            className="filter-field-select"
            value={gender}
            onChange={(e) => setGender(e.target.value)}
          >
            <option value="">All Genders</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Transgender">Transgender</option>
          </select>

          <select
            className="filter-field-select"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">All Status</option>
            <option value="true">Active</option>
            <option value="false">Inactive</option>
          </select>

          <button className="print-button" onClick={() => window.print()}>
            🖨️ Print
          </button>
        </div>

        <div className="table-wrapper">
          <table className="employees-table">
            <thead>
              <tr>
                <th>Photo</th>
                <th>Full Name</th>
                <th>Gender</th>
                <th>State</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((e) => (
                <tr key={e.id}>
                  <td>
                    {e.image ? (
                      <img src={e.image} className="profile-image" />
                    ) : (
                      <div className="profile-initials">
                        {e.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </td>
                  <td>
                    <span className="employee-name">{e.name}</span>
                  </td>
                  <td>
                    <div className="gender-display">
                      <span>{e.gender}</span>
                    </div>
                  </td>
                  <td>{e.state || "-"}</td>
                  <td>
                    <span
                      className={`status-pill ${
                        e.active
                          ? "status-pill-active"
                          : "status-pill-inactive"
                      }`}
                    >
                      {e.active ? "✓ Active" : "✗Inactive"}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button
                        className="action-btn action-btn-edit"
                        onClick={() => onEdit(e)}
                      >
                        <span>✏️</span>
                        Edit
                      </button>
                      <button
                        className="action-btn action-btn-delete"
                        onClick={() => onDelete(e.id)}
                      >
                        <span>🗑️</span>
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default EmployeeTable;
