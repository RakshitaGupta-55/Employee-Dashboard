import { useState } from "react";
import { login } from "../utils/auth";

interface Props {
  onLogin: () => void;
}

const Login = ({ onLogin }: Props) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [shake, setShake] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    setTimeout(() => {
      if (login(email, password)) {
        onLogin();
      } else {
        setShake(true);
        setTimeout(() => setShake(false), 500);
        alert("Invalid credentials");
      }
      setLoading(false);
    }, 800);
  };

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }

        @keyframes slideInFromLeft {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }

        @keyframes slideInFromRight {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }

        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-10px); }
          75% { transform: translateX(10px); }
        }

        .auth-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f6f5f7;
          font-family: 'Montserrat', sans-serif;
        }

        .container-wrapper {
          background: #fff;
          border-radius: 10px;
          box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
          position: relative;
          overflow: hidden;
          width: 768px;
          max-width: 100%;
          min-height: 480px;
        }

        .form-container {
          position: absolute;
          top: 0;
          height: 100%;
          transition: all 0.6s ease-in-out;
        }

        .sign-in-container {
          left: 0;
          width: 50%;
          z-index: 2;
        }

        .container-wrapper.right-panel-active .sign-in-container {
          transform: translateX(100%);
        }

        .sign-up-container {
          left: 0;
          width: 50%;
          opacity: 0;
          z-index: 1;
        }

        .container-wrapper.right-panel-active .sign-up-container {
          transform: translateX(100%);
          opacity: 1;
          z-index: 5;
          animation: slideInFromLeft 0.6s;
        }

        .form-inner {
          background: #FFFFFF;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          padding: 0 50px;
          height: 100%;
          text-align: center;
        }

        .form-title {
          font-weight: bold;
          margin: 0 0 10px;
          font-size: 32px;
          color: #000;
        }

        .social-container {
          margin: 20px 0;
        }

        .social-container a {
          border: 1px solid #DDDDDD;
          border-radius: 50%;
          display: inline-flex;
          justify-content: center;
          align-items: center;
          margin: 0 5px;
          height: 40px;
          width: 40px;
          transition: all 0.3s ease;
          text-decoration: none;
          color: #333;
        }

        .social-container a:hover {
          background: #f6f5f7;
          border-color: #2bff75ff;
        }

        .form-text {
          font-size: 14px;
          font-weight: 100;
          line-height: 20px;
          letter-spacing: 0.5px;
          margin: 15px 0 20px;
          color: #666;
        }

        .form-input {
          background-color: #eee;
          border: none;
          padding: 12px 15px;
          margin: 8px 0;
          width: 100%;
          border-radius: 5px;
          font-size: 14px;
        }

        .form-input:focus {
          outline: none;
          background-color: #e0e0e0;
        }

        .forgot-password {
          color: #333;
          font-size: 14px;
          text-decoration: none;
          margin: 15px 0;
          display: block;
        }

        .forgot-password:hover {
          text-decoration: underline;
        }

        .btn-auth {
          border-radius: 20px;
          border: 1px solid #2bff75ff;
          background: linear-gradient(to right, #2bff75ff, #6441ffff);
          color: #FFFFFF;
          font-size: 12px;
          font-weight: bold;
          padding: 12px 45px;
          letter-spacing: 1px;
          text-transform: uppercase;
          transition: transform 80ms ease-in;
          cursor: pointer;
          margin-top: 10px;
          border: none;
        }

        .btn-auth:hover {
          opacity: 0.9;
        }

        .btn-auth:active {
          transform: scale(0.95);
        }

        .btn-auth:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .overlay-container {
          position: absolute;
          top: 0;
          left: 50%;
          width: 50%;
          height: 100%;
          overflow: hidden;
          transition: transform 0.6s ease-in-out;
          z-index: 100;
        }

        .container-wrapper.right-panel-active .overlay-container {
          transform: translateX(-100%);
        }

        .overlay {
          background: linear-gradient(to right, #2bff75ff, #6441ffff);
          background-repeat: no-repeat;
          background-size: cover;
          background-position: 0 0;
          color: #FFFFFF;
          position: relative;
          left: -100%;
          height: 100%;
          width: 200%;
          transform: translateX(0);
          transition: transform 0.6s ease-in-out;
        }

        .container-wrapper.right-panel-active .overlay {
          transform: translateX(50%);
        }

        .overlay-panel {
          position: absolute;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          padding: 0 40px;
          text-align: center;
          top: 0;
          height: 100%;
          width: 50%;
          transform: translateX(0);
          transition: transform 0.6s ease-in-out;
        }

        .overlay-left {
          transform: translateX(-20%);
        }

        .container-wrapper.right-panel-active .overlay-left {
          transform: translateX(0);
        }

        .overlay-right {
          right: 0;
          transform: translateX(0);
        }

        .container-wrapper.right-panel-active .overlay-right {
          transform: translateX(20%);
        }

        .overlay-title {
          font-size: 32px;
          font-weight: bold;
          margin-bottom: 15px;
        }

        .overlay-text {
          font-size: 14px;
          font-weight: 300;
          line-height: 20px;
          letter-spacing: 0.5px;
          margin: 20px 0 30px;
        }

        .btn-ghost {
          background-color: transparent;
          border: 1px solid #FFFFFF;
          border-radius: 20px;
          color: #FFFFFF;
          font-size: 12px;
          font-weight: bold;
          padding: 12px 45px;
          letter-spacing: 1px;
          text-transform: uppercase;
          transition: all 0.3s ease;
          cursor: pointer;
        }

        .btn-ghost:hover {
          background-color: #FFFFFF;
          color: #2bff75ff;
        }

        .shake-animation {
          animation: shake 0.5s ease;
        }

        @media (max-width: 768px) {
          .container-wrapper {
            width: 100%;
            min-height: 600px;
          }
          
          .form-container {
            width: 100% !important;
            position: relative;
          }
          
          .overlay-container {
            display: none;
          }
        }
      `}</style>

      <div className="auth-container">
        <div className={`container-wrapper ${isSignUp ? 'right-panel-active' : ''}`}>
          {/* Sign In Form */}
          <div className="form-container sign-in-container">
            <div className={`form-inner ${shake ? 'shake-animation' : ''}`}>
              <h1 className="form-title">Log In</h1>
              <div className="social-container">
                <a href="https://www.facebook.com/" className="social"><span>f</span></a>
                <a href="https://www.google.com/" className="social"><span>G+</span></a>
                <a href="https://www.linkedin.com/" className="social"><span>in</span></a>
              </div>
              <span className="form-text">or use your account</span>
              <input 
                type="email" 
                placeholder="Email" 
                className="form-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
              />
              <input 
                type="password" 
                placeholder="Password" 
                className="form-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
              {/*<a href="#" className="forgot-password">Forgot your password?</a>*/}
              <button 
                className="btn-auth" 
                onClick={submit}
                disabled={loading}
              >
                {loading ? 'Signing In...' : 'LOG IN'}
              </button>
            </div>
          </div>

          {/* Sign Up Form */}
          <div className="form-container sign-up-container">
            <div className="form-inner">
              <h1 className="form-title">Create Account</h1>
              <div className="social-container">
                <a href="https://www.facebook.com/" className="social"><span>f</span></a>
                <a href="https://www.google.com/" className="social"><span>G+</span></a>
                <a href="https://www.linkedin.com/" className="social"><span>in</span></a>
              </div>
              <span className="form-text">or use your email for registration</span>
              <input type="text" placeholder="Name" className="form-input" />
              <input type="email" placeholder="Email" className="form-input" />
              <input type="password" placeholder="Password" className="form-input" />
              {/*<button className="btn-auth">SIGN UP</button>*/}
            </div>
          </div>

          {/* Overlay */}
          <div className="overlay-container">
            <div className="overlay">
              <div className="overlay-panel overlay-left">
                <h1 className="overlay-title">Welcome Back!</h1>
                <p className="overlay-text">
                  To keep connected with us please login with your personal info
                </p>
                <button 
                  className="btn-ghost" 
                  onClick={() => setIsSignUp(false)}
                >
                  LOG IN
                </button>
              </div>
              <div className="overlay-panel overlay-right">
                <h1 className="overlay-title">Hello, Friends!</h1>
                <p className="overlay-text">
                  Enter your details and start journey with us
                </p>
                {/*<button 
                  className="btn-ghost" 
                  onClick={() => setIsSignUp(true)}
                >
                  SIGN UP
                </button>*/}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;