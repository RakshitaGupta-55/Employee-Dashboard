import { useEffect, useState } from "react";
import type { Employee } from "../utils/storage";

interface Props {
  onSave: (e: Employee) => void;
  editing: Employee | null;
}

const EmployeeForm = ({ onSave, editing }: Props) => {
  const [form, setForm] = useState<Employee>({
    id: 0,
    name: "",
    gender: "",
    dob: "",
    state: "",
    active: true,
    image: "",
  });

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editing) {
      setForm(editing);
    } else {
      setForm({
        id: 0,
        name: "",
        gender: "",
        dob: "",
        state: "",
        active: true,
        image: "",
      });
    }
  }, [editing]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.name.trim()) {
      alert("Please enter employee name");
      return;
    }
    if (!form.gender) {
      alert("Please select gender");
      return;
    }

    setSaving(true);
    setTimeout(() => {
      onSave(form);
      setForm({
        id: 0,
        name: "",
        gender: "",
        dob: "",
        state: "",
        active: true,
        image: "",
      });
      setSaving(false);
    }, 400);
  };

  const imageHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("File size must be less than 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = () =>
      setForm({ ...form, image: reader.result as string });
    reader.readAsDataURL(file);
  };

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }

        .employee-form-wrapper {
          width: 100%;
          max-width: 520px;
          margin: 0 auto;
          padding: 30px;
          border-radius: 16px;
          background: #fff;
          box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .form-title-wrapper {
          font-size: 22px;
          font-weight: 700;
          margin-bottom: 25px;
          display: flex;
          align-items: center;
          gap: 10px;
          background: linear-gradient(135deg,#667eea,#764ba2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .form-title-icon {
          width: 34px;
          height: 34px;
          border-radius: 8px;
          background: linear-gradient(135deg,#667eea,#764ba2);
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        }

        .input-group {
          margin-bottom: 18px;
        }

        .input-label {
          font-size: 13px;
          font-weight: 600;
          margin-bottom: 6px;
          display: block;
          color: #555;
        }

        .input-field,
        .select-field {
          width: 100%;
          height: 46px;
          padding: 10px 14px;
          border-radius: 10px;
          border: 2px solid #e5e5e5;
          font-size: 14px;
        }

        .input-field:focus,
        .select-field:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 4px rgba(102,126,234,0.15);
        }

        .upload-area {
          border: 2px dashed #ccc;
          border-radius: 12px;
          padding: 25px;
          text-align: center;
          position: relative;
        }

        .upload-area input {
          position: absolute;
          inset: 0;
          opacity: 0;
        }

        .preview-wrapper {
          text-align: center;
        }

        .preview-img {
          width: 110px;
          height: 110px;
          border-radius: 50%;
          object-fit: cover;
        }

        .remove-btn {
          margin-top: 10px;
          background: #f44336;
          color: #fff;
          border: none;
          padding: 8px 14px;
          border-radius: 6px;
          cursor: pointer;
        }

        .checkbox-container {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #f5f6f8;
          padding: 12px;
          border-radius: 10px;
        }

        .save-btn {
          width: 100%;
          height: 52px;
          background: linear-gradient(135deg,#11998e,#38ef7d);
          border: none;
          border-radius: 12px;
          color: #fff;
          font-weight: 700;
          font-size: 15px;
          cursor: pointer;
        }

        .save-btn:disabled {
          opacity: 0.6;
        }

        /* ===== TABLET ===== */
        @media (min-width: 600px) {
          .employee-form-wrapper {
            max-width: 560px;
            padding: 34px;
          }
        }

        /* ===== LAPTOP ===== */
        @media (min-width: 992px) {
          .employee-form-wrapper {
            max-width: 620px;
            padding: 38px;
          }
        }

        /* ===== LARGE DESKTOP ===== */
        @media (min-width: 1200px) {
          .employee-form-wrapper {
            max-width: 680px;
          }
        }

        /* ===== SMALL MOBILE ===== */
        @media (max-width: 360px) {
          .form-title-wrapper {
            font-size: 18px;
          }
          .save-btn {
            height: 46px;
            font-size: 13px;
          }
        }
      `}</style>

      <form className="employee-form-wrapper" onSubmit={submit}>
        <h5 className="form-title-wrapper">
          <span className="form-title-icon">
            {editing ? "✏️" : "➕"}
          </span>
          {editing ? "Edit Employee" : "Add New Employee"}
        </h5>

        <div className="input-group">
          <label className="input-label">Full Name *</label>
          <input
            className="input-field" placeholder="Enter employee full name"
            value={form.name}
            onChange={(e) =>
              setForm({ ...form, name: e.target.value })
            }
          />
        </div>

        <div className="input-group">
          <label className="input-label">Gender *</label>
          <select
            className="select-field"
            value={form.gender}
            onChange={(e) =>
              setForm({ ...form, gender: e.target.value })
            }
          >
            <option value="">Select Gender</option> <option value="Male">♂️ Male</option> <option value="Female">♀️ Female</option> <option value="Transgender">⚧️ Transgender</option> </select>
        </div>

        <div className="input-group">
          <label className="input-label">Date of Birth</label>
          <input
            type="date"
            className="input-field"
            value={form.dob}
            onChange={(e) =>
              setForm({ ...form, dob: e.target.value })
            }
          />
        </div>

        <div className="input-group">
          <label className="input-label">State</label>
          <input
            className="input-field" placeholder="Enter employee state"
            value={form.state}
            onChange={(e) =>
              setForm({ ...form, state: e.target.value })
            }
          />
        </div>

        <div className="input-group">
          <label className="input-label">Profile Picture</label>
          {!form.image ? (
            <div className="upload-area">
              <input type="file" accept="image/*" onChange={imageHandler} />
              📷 Click to upload
            </div>
          ) : (
            <div className="preview-wrapper">
              <img src={form.image} className="preview-img" />
              <br />
              <button
                type="button"
                className="remove-btn"
                onClick={() => setForm({ ...form, image: "" })}
              >
                Remove
              </button>
            </div>
          )}
        </div>

        <div className="input-group">
          <div className="checkbox-container">
            <input
              type="checkbox"
              checked={form.active}
              onChange={(e) =>
                setForm({ ...form, active: e.target.checked })
              }
            />
            <label>
              {form.active ? "Active Employee" : "Inactive Employee"}
            </label>
          </div>
        </div>

        <button className="save-btn" disabled={saving}>
          {saving ? "Saving..." : editing ? "Update Employee" : "Save Employee"}
        </button>
      </form>
    </>
  );
};

export default EmployeeForm;
