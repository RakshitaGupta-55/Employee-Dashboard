import { useState } from "react";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import { isLoggedIn } from "./utils/auth";

const App = () => {
  const [loggedIn, setLoggedIn] = useState<boolean>(isLoggedIn());

  return loggedIn ? (
    <Dashboard
      onLogout={() => {
        localStorage.removeItem("login");
        setLoggedIn(false);
      }}
    />
  ) : (
    <Login onLogin={() => setLoggedIn(true)} />
  );
};

export default App;
