export const login = (email: string, password: string): boolean => {
  if (email && password) {
    localStorage.setItem("login", "true");
    return true;
  }
  return false;
};

export const isLoggedIn = (): boolean => {
  return localStorage.getItem("login") === "true";
};
